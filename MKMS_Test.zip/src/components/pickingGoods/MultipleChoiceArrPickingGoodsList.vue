<template>
  <div id="container">
    <div class="header">
    <nav class="navbar navbar-inverse navbar-fixed-top title">
      <!-- <img class="backPoint clearfix:after" sr c="../assets/backPoint.png"  @click="$router.back(-1)"> -->
      <img class="backPoint" src="../../assets/backPoint.png" />

      <div id="title" class="titlename">拣货货品列表</div>
    </nav>

    <div id="searchBox">
      <img class="codeIcon" src="../../assets/noglasses.png" />
      <input class="searchInput" type="text" v-model="dn" @keyup.enter="searchpickdata(dn,false)"
        v-on:blur="resetbackground()" placeholder="支持输入或扫描" />
      <!-- <img class="camera"  @click="showcamerascan()" v-if="showCamera" src="../assets/cameraIcon.png" > -->

      <div class="searchButton" @click="getpickdata(dn,false)">搜索</div>
      <div class="clearfix"></div>
    </div>
  </div>
    <div id="content">
      <div class="contentTitle">
        <div>陈列图</div>
        <div>货号</div>
        <div>名称</div>
        <div>数量</div>
        <div>状态</div>
      </div>
      <div id="contentItem">
        <div class="goodsList" @click="toDetails()">
          <div>1xxx01</div>
          <div>100101</div>
          <div>洗头水</div>
          <div>0/3</div>
          <div>待拣货</div>
        </div>
        <div class="goodsList">
          <div>1xxx01</div>
          <div>100101</div>
          <div>沐浴露</div>
          <div>0/2</div>
          <div>待拣货</div>
        </div>
        <div class="goodsList">
          <div>1xxx01</div>
          <div>100101</div>
          <div>矿泉水</div>
          <div>0/2</div>
          <div>待拣货</div>
        </div>
        <div class="goodsList">
          <div>1xxx01</div>
          <div>100101</div>
          <div>润唇膏</div>
          <div>0/2</div>
          <div>待拣货</div>
        </div>
        <div class="goodsList">
          <div>1xxx01</div>
          <div>100101</div>
          <div>牙膏</div>
          <div>0/2</div>
          <div>待拣货</div>
        </div>
        <div class="goodsList">
          <div>1xxx01</div>
          <div>100101</div>
          <div>购物袋</div>
          <div>0/2</div>
          <div>待拣货</div>
        </div>
        <div class="goodsList">
          <div>1xxx01</div>
          <div>100101</div>
          <div>口红</div>
          <div>0/2</div>
          <div>待拣货</div>
        </div>
        <div class="goodsList">
          <div>1xxx01</div>
          <div>100101</div>
          <div>口红</div>
          <div>0/2</div>
          <div>待拣货</div>
        </div>
        <div class="goodsList">
          <div>1xxx01</div>
          <div>100101</div>
          <div>口红</div>
          <div>0/2</div>
          <div>待拣货</div>
        </div>
        <div class="goodsList">
          <div>1xxx01</div>
          <div>100101</div>
          <div>口红</div>
          <div>0/2</div>
          <div>待拣货</div>
        </div>
        <div class="goodsList">
          <div>1xxx01</div>
          <div>100101</div>
          <div>口红</div>
          <div>0/2</div>
          <div>待拣货</div>
        </div>
      </div>
    </div>

    <div id="ButtonGroup">
      <div class="leftBtn">
        完成拣货

      </div>
      <div class="rightBtn">
        打印订单
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        dn: "",
      };
    },
    methods: {},
    computed: {

      // stopGetOrderParam.data.storeShutoutBeginTime = this.getNowDate(false)
    },
    mounted() {

     
    },
    methods: {
      computDateParam() {

      },
      toDetails(){
        this.$router.push("MultipleChoiceArrPickingGoodsDetails")
      }
    }

  };

</script>

<style scoped>
  /* 顶部================================ */
  .title {
    height: 3rem;
    display: flex;
    align-items: center;
    text-align: center;
    background: #fff;
  }

  #title {
    flex: 1;
  }

  .backPoint {
    position: absolute;
    width: 1rem;
    padding-left: 1rem;
  }

  .codeIcon {
    width: 1rem;
    position: relative;
    left: 2rem;
  }

  #searchBox {
    display: flex;
    align-items: center;
    background: #fff;
  }

  .searchButton {
    margin-left: auto;
    padding-right: 1rem;
  }

  .searchInput {
    border: none;
    background: #f2f2f2;
    height: 2rem;
    border-radius: 0.6rem;
    padding-left: 2rem;
    width: 70.5%;
    font-size: 0.8rem;
  }

  /* 内容 */
  #content {
    padding-top: 1rem;
    background: #fff;
  }

  .contentTitle {
    display: flex;
    justify-content: space-around;
    padding-bottom: .5rem;
  }

  #contentItem {
    height: 33rem;
    overflow: auto;
  }

  .goodsList {
    display: flex;
    justify-content: space-around;
    align-items: center;
    height: 3rem;
    border-bottom: 1px solid #f2f2f2;
  }

  /* 底部按钮 */
  #ButtonGroup {
    position: fixed;
    width: 100%;
    height: 3rem;
    line-height: 3rem;
    bottom: 0;
    text-align: center;
    display: flex;
  }

  .leftBtn {
    width: 50%;
    background: #42b983;
    color: #fff;
  }

  .rightBtn {
    width: 50%;
    background: #FAE100;
    color: #000;

  }

  .header{
    /* position:fixed;
    top: 0;
    width: 100%; */
  }

  /* <div id="ButtonGroup">
      <div class="leftBtn">
        打印订单
      </div>
      <div class="rightBtn"> */

</style>
